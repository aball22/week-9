package org.example.week9.d6;

abstract public class Vehicle {
    public abstract void startEngine();

    public void stopEngine() {
        System.out.println("Vehicle engine stopped");
    }
}
