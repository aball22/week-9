package org.example.week9.d5.e2;

abstract public class Shape {
    public abstract double calculateArea();

    public void displayArea(){
        System.out.print("The area of the shape is: ");
    }
}
