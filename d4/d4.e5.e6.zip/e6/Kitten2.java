package org.example.week9.d4.e6;

public class Kitten2 extends Cat {
    public void eat() {
        System.out.println("kitten2 eats snacks");
    }
    protected void sleep() {
        System.out.println("kitten2 sleeps a lot");
    }
}
