package org.example.week9.d4.e6;

public class Kitten3 extends Cat {
    public void eat() {
        System.out.println("kitten3 eats everything");
    }
    protected void sleep() {
        System.out.println("kitten3 sleeps a lot");
    }
}
