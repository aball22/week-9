package org.example.week9.d4.e6;

public class Kitten1 extends Cat {
    public void eat() {
        System.out.println("kitten1 eats milk");
    }
    protected void sleep() {
        System.out.println("kitten1 sleeps a lot");
    }
}
