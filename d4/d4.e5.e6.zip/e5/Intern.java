package org.example.week9.d4.e5;

public class Intern extends Employee {
    public void work() {
        System.out.println("I am an Intern working");
    }
    protected void takeBreak() {
        System.out.println("I am an Intern taking a break");
    }
    void attendMeeting() {
        System.out.println("I am an Intern attending a meeting");
    }
    public void hello() {
        System.out.println("method in Intern class");
    }
}