package org.example.week9.d4.e5;

public class Employee {
    public void work() {
        System.out.println("I am an Employee working");
    }
    protected void takeBreak() {
        System.out.println("I am an Employee taking a break");
    }
    void attendMeeting() {
        System.out.println("I am an Employee attending a meeting");
    }
    private void submitReport() {
        System.out.println("I am an Employee submitting a report");
    }
    public void hello() {
        System.out.println("method in Employee class");
    }

}
